あなたはこのアイデアの実装担当エージェントです。要件定義、仕様、設計、MVP実装、検証まで、この開発パックに沿って進めてください。

## 対象アイデア

- 親分類: Plugins
- 領域: AdobePlugin
- No.: 1
- 分野: 画像納品・EC素材
- アイデア: 商品画像納品チェッカー
- リポジトリ名: product-image-delivery-checker
- Integration target: Photoshop

## 元アイデア

- 概要: 解像度、カラープロファイル、余白、透過、レイヤー名を検査し、BOOTHやEC向けの書き出し条件へ接続する。
- 課題: 商品画像の形式ミス、サイズ違い、背景透過漏れが後工程で見つかる。
- 類似サービス・アプリ: Adobe Photoshop, TinyPNG, ImageOptim, BOOTH管理画面
- 差別化ポイント: PSD制作中に納品条件を直接確認し、修正候補と書き出しを同じパネルで扱う。

## 最初に行うこと

1. このZIP内の `01_REQUIREMENTS.md`、`02_SPECIFICATION.md`、`03_DESIGN.md` を読む。
2. 実装前に未決事項を洗い出す。
3. 既存リポジトリがある場合は、先に README、docs、Issue、テスト、現在のアーキテクチャを確認する。
4. 新規リポジトリの場合は、`04_IMPLEMENTATION_PLAN.md` のMVPから開始する。
5. 実装前に、プラットフォーム、保存方式、主要ユーザーフロー、検証方法を明記する。

## 領域別の重点事項

- ホストアプリのバージョン、権限、パネル/メニュー導線、ファイル入出力境界を明確にする。
- ホストアプリのデータモデル、選択状態、書き出しパイプライン、失敗パターンを前提に設計する。
- サンプルプロジェクトと実際のホストアプリ操作で検証する。

## Done Means

- The MVP works.
- The main flow has been manually verified.
- Test or verification steps are repeatable.
- README or usage notes are updated.
- Remaining work is captured in release checklist or issues.
