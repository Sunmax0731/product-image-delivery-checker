# 商品画像納品チェッカー 開発パック

| 項目 | 内容 |
| --- | --- |
| 領域 | AdobePlugin |
| No. | 1 |
| 分野 | 画像納品・EC素材 |
| アイデア | 商品画像納品チェッカー |
| リポジトリ名 | product-image-delivery-checker |
| Integration target | Photoshop |
| 概要 | 解像度、カラープロファイル、余白、透過、レイヤー名を検査し、BOOTHやEC向けの書き出し条件へ接続する。 |
| 課題 | 商品画像の形式ミス、サイズ違い、背景透過漏れが後工程で見つかる。 |
| 類似サービス・アプリ | Adobe Photoshop, TinyPNG, ImageOptim, BOOTH管理画面 |
| 差別化ポイント | PSD制作中に納品条件を直接確認し、修正候補と書き出しを同じパネルで扱う。 |

## 目的

このZIPには、`AdobePlugin` 領域のアイデア `商品画像納品チェッカー` を実装可能なプロジェクトへ落とし込むための初期ドキュメントが含まれています。

## 含まれるファイル

- START_PROMPT.md
- README.md
- 01_REQUIREMENTS.md
- 02_SPECIFICATION.md
- 03_DESIGN.md
- 04_IMPLEMENTATION_PLAN.md
- 05_TEST_PLAN.md
- 06_RELEASE_CHECKLIST.md
- metadata.json

## 使い方

1. Codexまたは他のコーディングエージェントへの最初のプロンプトとして `START_PROMPT.md` を使用する。
2. 実装前に要件、仕様、設計を確認する。
3. MVPを実装し、テスト計画に沿って検証する。
